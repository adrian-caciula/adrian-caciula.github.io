# -*- coding: utf-8 -*-
"""
Created on Sun Apr  1 13:33:45 2018

@author: Parmenides
"""

# =============================================================================
# Conditional if else, Exercise 3
# 0 points possible (ungraded)
# Write a program which asks the user to type a string and then prints "Yes" if "dog" is in that string, otherwise prints "No"
# =============================================================================


# Type your code here

data = (input("Please type a sentence with an animal : "))
if 'dog' in data:
    print("Yes")
else:
    print("No")

