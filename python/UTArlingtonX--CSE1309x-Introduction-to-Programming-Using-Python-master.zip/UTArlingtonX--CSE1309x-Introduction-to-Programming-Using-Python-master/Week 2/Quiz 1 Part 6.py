# -*- coding: utf-8 -*-
"""
Created on Sun Apr  1 13:33:45 2018

@author: Parmenides
"""

# =============================================================================
# Part 6 (This Part Has 1 Program)
# 10.0/10.0 points (graded)
# Complete the following program such that it calculates and prints the average of the elements of the given list.
# =============================================================================

​# Type your code here
sample_list = [2, 10, 3, 5]
print(sum(sample_list)/len(sample_list))

