# -*- coding: utf-8 -*-
"""
Created on Sun Apr  1 13:33:45 2018

@author: Parmenides
"""

# =============================================================================
# Part 4 (This Part Has 1 program )
# 10.0/10.0 points (graded)
# Write a program that asks the user for an integer 'x' and prints the value of y after evaluating the following expression:
# 
# y = x**2 - 12*x + 11
# =============================================================================

# Type your code here
x = int(input("Please provide an integer: "))
y = x**2 - 12*x + 11
print(y)



