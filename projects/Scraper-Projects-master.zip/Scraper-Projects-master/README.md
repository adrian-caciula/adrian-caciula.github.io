# Scraper Projects

This repository will contain all of my web scraping effort from the first code that i wrote until when i **git gud** at web scraping.

# List of Projects

- BrainyQuotes scraper ( My very first effort)
- Trip Advisor
- IMDB Horror movies list (including ratings, actors name and synopsis)
