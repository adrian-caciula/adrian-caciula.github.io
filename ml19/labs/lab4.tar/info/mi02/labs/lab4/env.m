function [s_new, reward] = env(s_old, action)
% env returns the new state s_new and reward
% when executing action in state s_old
% possible states s_1,..,s_25
% possible actions 1,...,4

s_old_x=mod(s_old-1,5)+1;
s_old_y=fix((s_old-1)/5)+1;

if (s_old_y==5) & (s_old_x==5)
  reward=10;
  s_new=startstate;
  return;
end

switch (action)
 case 1
  s_old_y=s_old_y+1;
 case 2
  s_old_x=s_old_x+1;
 case 3
  s_old_y=s_old_y-1;
 case 4
  s_old_x=s_old_x-1;
end

if ((action==2) | (action==4))
  switch (s_old_x)
   case 2
    s_old_y=s_old_y + floor(2.0*rand(1)+1);
   case 3
    s_old_y=s_old_y + floor(3.0*rand(1)+1);
   case 4
    s_old_y=s_old_y + floor(4.0*rand(1)+1);
  end
end

if (s_old_y >5) | (s_old_y <1) | (s_old_x >5) | (s_old_x <1) 
  s_new=startstate;
  reward=-1;
else
  reward=0;
  s_new=5*(s_old_y-1)+s_old_x;
end



  