function plot_v_td(V, range, pi)
% V state value function of size 16x1
% range upper and lower limit for colorplot of V , default [-5 15]
% pi : policy 16x1 vector , 1=North, 2=East, 3=South, 4=West 
if (nargin==1)
  range = [-5 15];
else
  if (length(range) ~= 2)
    error('argument range must be of length 2');
    return;
  end
end
if (length(V) ~= 25)
  error('argument V must be of length 25');
  return;
end 
V = reshape(V,5,5);
imagesc(1:5,1:5,V',range);
colorbar;
if (nargin == 3)  % plot policy
  if (length(pi) ~= 25)
    error('argument pi must be of length 25');
    return;
  end 
  pi=reshape(pi,5,5);
  for i=1:5
    for j=1:5
      switch(pi(i,j))
       case 1
	line([i i],[j+0.1 j+0.4],'LineWidth',4.0)
        line([i i],[j+0.39 j+0.4],'LineWidth',4.0, 'Marker', 'v')
       case 2
	line([i+0.1 i+0.4],[j j],'LineWidth',4.0)
        line([i+0.39 i+0.4],[j j],'LineWidth',4.0, 'Marker', '>')
       case 3
	line([i i],[j-0.1 j-0.4],'LineWidth',4.0)
        line([i i],[j-0.4 j-0.39],'LineWidth',4.0, 'Marker', '^')
       case 4
	line([i-0.1 i-0.4],[j j],'LineWidth',4.0)
	line([i-0.39 i-0.4],[j j],'LineWidth',4.0, 'Marker', '<')
      end
    end
  end
end
axis off;
drawnow;