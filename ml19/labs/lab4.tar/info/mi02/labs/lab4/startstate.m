function s=startstate
s=5.0*floor(5.0*rand(1))+1;