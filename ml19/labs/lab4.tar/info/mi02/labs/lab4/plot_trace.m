function plot_trace(states,actions,tlength)
% states: sequence of previously visited states
% actions: sequence of previous actions [optional]
% it is assumed that the last action corresponds to 
% the second last state, the second last action to
% the third last state etc.
% tlength: length of the trace, how many steps 
% of the history are plotted [optional default 8]
% the most recent state is shown by a large red square
% the second last state with a smaller square etc.

clf;
if nargin<3
  n=8;
else
  n=tlength;
end

cm=colormap;

sz=length(states);
n=min(sz,n);
%for i=1:5
%  for j=1:5
%    rectangle('Position',[i j 1 1],'FaceColor','Blue','EdgeColor','Black','LineWidth',8.0);
%  end
%end
rectangle('Position',[0.5 0.5 5.0 5.0],'FaceColor','White','EdgeColor','Black','LineWidth',8.0);

width=0.5;
for k=sz:-1:sz-n+1
  s_x=mod(states(k)-1,5)+1;
  s_y=4-fix((states(k)-1)/5)+1;
  rectangle('Position',[s_x-0.5*width s_y-0.5*width width ...
		    width],'FaceColor',cm(63-3*(sz-k),:));
  width=width*0.9;
end

  if (nargin>=2) % show actions
    for k=sz-1:-1:sz-n+1
      s_x=mod(states(k)-1,5)+1;
      s_y=4-fix((states(k)-1)/5)+1;
      switch(actions(k))
       case 3
	line([s_x s_x],[s_y+0.1 s_y+0.4],'LineWidth',4.0)
        line([s_x s_x],[s_y+0.39 s_y+0.4],'LineWidth',4.0, 'Marker', '^')
       case 2
	line([s_x+0.1 s_x+0.4],[s_y s_y],'LineWidth',4.0)
        line([s_x+0.39 s_x+0.4],[s_y s_y],'LineWidth',4.0, 'Marker', '>')
       case 1
	line([s_x s_x],[s_y-0.1 s_y-0.4],'LineWidth',4.0)
        line([s_x s_x],[s_y-0.4 s_y-0.39],'LineWidth',4.0, 'Marker', 'v')
       case 4
	line([s_x-0.1 s_x-0.4],[s_y s_y],'LineWidth',4.0)
	line([s_x-0.39 s_x-0.4],[s_y s_y],'LineWidth',4.0, 'Marker', '<')
      end
    end
  end   
axis off;  
drawnow;