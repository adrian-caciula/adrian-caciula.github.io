function plot_v(V, range, pi)
% V state value function of size 16x1
% range upper and lower limit for V , default [-10 30]
% pi : policy 16x1 vector , 1=North, 2=East, 3=South, 4=West 
if (nargin==1)
  range = [-10 30];
else
  if (length(range) ~= 2)
    error('argument range must be of length 2');
    return;
  end
end
if (length(V) ~= 16)
  error('argument V must be of length 16');
  return;
end 
V = reshape(V,4,4);
imagesc(1:4,1:4,V',range);
colorbar;
if (nargin == 3)  % plot policy
  pi=reshape(pi,4,4);
  for i=1:4
    for j=1:4
      switch(pi(i,j))
       case 3
	line([i i],[j+0.1 j+0.4],'LineWidth',4.0)
        line([i i],[j+0.39 j+0.4],'LineWidth',4.0, 'Marker', 'v')
       case 2
	line([i+0.1 i+0.4],[j j],'LineWidth',4.0)
        line([i+0.39 i+0.4],[j j],'LineWidth',4.0, 'Marker', '>')
       case 1
	line([i i],[j-0.1 j-0.4],'LineWidth',4.0)
        line([i i],[j-0.4 j-0.39],'LineWidth',4.0, 'Marker', '^')
       case 4
	line([i-0.1 i-0.4],[j j],'LineWidth',4.0)
	line([i-0.39 i-0.4],[j j],'LineWidth',4.0, 'Marker', '<')
      end
    end
  end
end
drawnow;