function [train,val]=fold(data,nfolds,n)
[sz,l]=size(data);
foldsize=sz/nfolds;
val=data((n-1)*foldsize+1:n*foldsize,:);
if (n==1)
  train=data(foldsize+1:sz,:);
else
  if (n==nfolds)
    train=data(1:(n-1)*foldsize,:);
  else
    train(1:(n-1)*foldsize,:)=data(1:(n-1)*foldsize,:);
    train((n-1)*foldsize+1:sz-foldsize,:)=data(n*foldsize+1:sz,:);
  end
end

