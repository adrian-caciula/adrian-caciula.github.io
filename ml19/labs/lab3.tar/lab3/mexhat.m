function f=mexhat(x,y)
 f=(sin(x).*sin(y))./((x.*y));
