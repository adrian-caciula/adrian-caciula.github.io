  document.getElementById("textForm").onsubmit = validate;
  function validate ()
  {
    var elt = document.getElementById("textForm");
    if (elt.userName.value == "")
    {
      window.alert ("Enter name");
      return false;
    }
    if (elt.email.value == "")
    {
      window.alert ("Enter e-mail");
      return false;
    }
    return true;
  }
