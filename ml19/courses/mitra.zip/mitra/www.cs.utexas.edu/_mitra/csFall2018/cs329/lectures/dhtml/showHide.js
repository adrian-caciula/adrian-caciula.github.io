function flipImag() {
  dom = document.getElementById("galaxy").style;

  if (dom.visibility == "visible")
    dom.visibility = "hidden";
  else
    dom.visibility = "visible";
}
