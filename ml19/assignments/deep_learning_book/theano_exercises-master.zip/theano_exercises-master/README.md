theano_exercises
================
Slides for session 1: https://drive.google.com/file/d/0B64011x02sIkdDB5MmdnRnNTbWc/edit?usp=sharing
Slides for session 2: https://drive.google.com/file/d/0B64011x02sIkOVpPY1B2WmVYa3c/edit?usp=sharing
Slides for session 3: https://drive.google.com/file/d/0B64011x02sIkWW9LLVV6QWtzRTg/edit?usp=sharing

Exercises for my tutorials on Theano
