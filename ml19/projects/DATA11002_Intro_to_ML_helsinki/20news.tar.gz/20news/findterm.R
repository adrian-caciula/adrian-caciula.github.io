findterm <- function( str ) {

	ind <- which( voc == str )
	ind

}

